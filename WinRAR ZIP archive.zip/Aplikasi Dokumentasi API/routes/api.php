<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\ApiController;
//use App\Http\Controllers\API\ApiController;
use App\Http\Controllers\API\CoordinateController;
use App\Http\Controllers\API\DestinasiWisataController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/apiregister', [ApiController::class, 'registerAPI']);
Route::post('/apilogin', [ApiController::class, 'loginAPI']);
Route::middleware('auth:sanctum')->get('/check-token', [ApiController::class, 'checkToken']);
Route::apiResource('/posts', App\Http\Controllers\API\PostController::class);
Route::apiResource('/destinasi-wisata', App\Http\Controllers\API\DestinasiWisataController::class);
Route::apiResource('/kordinat', App\Http\Controllers\API\CoordinateController::class);
Route::apiResource('/kategori', App\Http\Controllers\API\CategoryController::class);
//Route::middleware('auth:sanctum')->get('/destinasi-wisata', [DestinasiWisataController::class, 'index']);



    // Rute untuk menampilkan data destinasi wisata



    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/check-token', [ApiController::class, 'checkToken']);
});