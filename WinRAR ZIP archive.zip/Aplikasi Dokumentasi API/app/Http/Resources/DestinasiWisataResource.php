<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class DestinasiWisataResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->Place_Id, // Sesuaikan dengan nama kolom dalam tabel
            'nama' => $this->Place_Name, // Sesuaikan dengan nama kolom dalam tabel
            'lokasi' => $this->City, // Sesuaikan dengan nama kolom dalam tabel


            

            // tambahkan atribut lainnya sesuai kebutuhan
        ];
    }
}
