<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            
            
            
            'id' => $this->Place_Id,
            'nama' => $this->Place_Name, // Sesuaikan dengan nama kolom dalam tabel
            'category'=> $this ->Category,
            'rating'=> $this-> Rating,
            'harga'=>$this ->Price,
            'deskripsi'=>$this ->Description
            

            // tambahkan atribut lainnya sesuai kebutuhan
        ];
    }
}
