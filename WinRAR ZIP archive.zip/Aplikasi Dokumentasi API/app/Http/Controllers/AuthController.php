<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    protected function register()
    {
        return view('register');
    }

    protected function registerPost(Request $request)
    {
        $user = new User();

        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);

        $user->save();

        return redirect()->route('login')->with('success', 'Registrasi berhasil! Silakan masuk.');
    }

    protected function login()
    {
        return view('login');
    }

    protected function loginPost(Request $request)
    {
        $credetials = [
            'email' => $request->email,
            'password' => $request->password,
        ];

        if (Auth::attempt($credetials)) {
            return redirect('/home')->with('success', 'Login berhasil');
        }

        return back()->with('error', 'Email or Password salah');
    }

    protected function logout()
    {
        Auth::logout();

        return redirect()->route('login');
    }
}
//TODO
//TOKEN YANG GENERATE USER SAVE DI DATABASE USER FIELD remember_token
