<?php
namespace App\Http\Controllers\API;

use App\Models\DestinasiWisata;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\DestinasiWisataResource;
use Illuminate\Support\Facades\Auth;

class DestinasiWisataController extends Controller
{
    public function index(Request $request)
    {
        // Cek apakah pengguna autentikasi
        $user = Auth::guard('sanctum')->user();
        if (!$user) {
            return response()->json(['message' => 'Pengguna tidak ditemukan'], 401);
        }

        // Setelah melewati pengecekan token, lanjutkan dengan mengambil data destinasi wisata

        $id = $request->query('id');
        $lokasi = $request->query('lokasi');
        $nama = $request->query('nama');

        $destinasiWisataQuery = DestinasiWisata::query();

        if ($id) {
            $destinasiWisataQuery->where('Place_Id', $id);
        }
        if ($lokasi) {
            $destinasiWisataQuery->where('city', $lokasi);
        }
        if ($nama) {
            $destinasiWisataQuery->where('Place_Name', $nama);
        }



        $destinasiWisata = $destinasiWisataQuery->get();

        // Mengembalikan data destinasi wisata dalam bentuk resource
        return DestinasiWisataResource::collection($destinasiWisata);
    }
}



