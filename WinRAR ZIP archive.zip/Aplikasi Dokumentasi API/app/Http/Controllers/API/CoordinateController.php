<?php
namespace App\Http\Controllers\API;

use App\Models\DestinasiWisata;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\CoordinateResource;
use Illuminate\Support\Facades\Auth;

class CoordinateController extends Controller
{
    public function index(Request $request)
    {
        // Cek apakah pengguna autentikasi
        $user = Auth::guard('sanctum')->user();
        if (!$user) {
            return response()->json(['message' => 'Pengguna tidak ditemukan'], 401);
        }

        // Setelah melewati pengecekan token, lanjutkan dengan mengambil data destinasi wisata

        $kordinat = $request->query('kordinat');
        $longtitude = $request->query('longtitude');
        $latitude = $request->query('latitude');
        $id = $request->query('id');
        $destinasiWisataQuery = DestinasiWisata::query();

        if ($id) {
            $destinasiWisataQuery->where('Place_Id', $id);
        }
        if ($kordinat) {
            $destinasiWisataQuery->where('coordinate', $kordinat);
        }
        if ($longtitude) {
            $destinasiWisataQuery->where('long', $longtitude);
        }
        if ($latitude) {
            $destinasiWisataQuery->where('lat', $latitude);
        }
    

        $destinasiWisata = $destinasiWisataQuery->get();

        // Mengembalikan data destinasi wisata dalam bentuk resource
        return CoordinateResource::collection($destinasiWisata);
    }
}



