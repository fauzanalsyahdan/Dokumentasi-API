<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Validator;
use Auth;

class ApiController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum')->only('checkToken');
    }

    public function registerAPI(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Ada kesalahan',
                'data' => $validator->errors()
            ]);
        }

        $input = $request->all();
        $input['password'] = bcrypt($input['password']);
        $user = User::create($input);

        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Sukses register',
            'token' => $token
        ]);
    }

    public function loginAPI(Request $request)
    {
        $request->validate([
            'email' => 'email|required',
            'password' => 'required'
        ]);

        $credentials = request(['email', 'password']);
        if (!auth()->attempt($credentials)) {
            return response()->json([
                'message' => 'Data yang diberikan tidak valid.',
                'errors' => [
                    'password' => [
                        'Kredensial tidak valid'
                    ],
                ]
            ], 422);
        }

        $user = User::where('email', $request->email)->first();
        $authToken = $user->createToken('auth-token')->plainTextToken;

        return response()->json([
            'access_token' => $authToken,
            'keterangan' => $user
        ]);
    }

    public function checkToken(Request $request)
    {
        // Mendapatkan pengguna yang terkait dengan token
        $user = Auth::guard('sanctum')->user();

        // Jika pengguna tidak ditemukan
        if (!$user) {
            return response()->json(['message' => 'Pengguna tidak ditemukan'], 401);
        }

        // Jika token valid
        return response()->json(['message' => 'Token valid'], 200);
    }
}

