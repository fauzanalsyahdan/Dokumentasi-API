<?php
namespace App\Http\Controllers\API;

use App\Models\DestinasiWisata;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\CategoryResource;
use Illuminate\Support\Facades\Auth;

class CategoryController extends Controller
{
    public function index(Request $request)
    {
        // Cek apakah pengguna autentikasi
        $user = Auth::guard('sanctum')->user();
        if (!$user) {
            return response()->json(['message' => 'Pengguna tidak ditemukan'], 401);
        }

        // Setelah melewati pengecekan token, lanjutkan dengan mengambil data destinasi wisata

        $id = $request->query('id');
        $nama = $request->query('nama');
        $rating = $request->query('rating');
        $category = $request->query('kategori');
        $deskripsi = $request->query('deskripsi');

        $destinasiWisataQuery = DestinasiWisata::query();

        if ($id) {
            $destinasiWisataQuery->where('place_id', $id);
        }
        if ($nama) {
            $destinasiWisataQuery->where('Place_Name', $nama);
        }
        if ($rating) {
            $destinasiWisataQuery->where('rating', '=', $rating);
        }
        if ($category) {
            $destinasiWisataQuery->where('Category', $category);
        }
        if ($deskripsi) {
            $destinasiWisataQuery->where('description', $deskripsi);
        }

        $destinasiWisata = $destinasiWisataQuery->get();

        // Mengembalikan data destinasi wisata dalam bentuk resource
        return CategoryResource::collection($destinasiWisata);
    }
}



