<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DestinasiWisata extends Model
{
    use HasFactory;
    use HasFactory;

    protected $table = 'destinasi_wisata_indonesia';

    protected $fillable = [
        'Place_Id',
        'Place_Name',
        'Description',
        'Category',
        'City',
        'Price',
        'Rating',
        'Time_Minutes',
        'Coordinate',
        'Lat',
        'Long',
        'Rating_Count',
        // tambahkan kolom lainnya sesuai kebutuhan
    ];
}
