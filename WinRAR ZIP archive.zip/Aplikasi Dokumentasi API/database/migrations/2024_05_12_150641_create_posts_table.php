<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up(): void
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->id();
            $table->string('image');
            $table->string('title');
            $table->text('content');
            $table->timestamps();
            $table->int('Place_Id');
            $table->varchar('Place_Name');
            $table->varchar('Description');
            $table->varchar('Category')	;
            $table->varchar('City')	;
            $table->int('Price')	;
            $table->int('Rating')	;
            $table->varchar('Time_Minutes')	;
            $table->varchar('Coordinate')	;
            $table->int('Lat')	;
            $table->int('Long')	;
            $table->varchar('Column1')	;
            $table->int('_1')	;
            $table->int('Rating_Count')	;
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
}