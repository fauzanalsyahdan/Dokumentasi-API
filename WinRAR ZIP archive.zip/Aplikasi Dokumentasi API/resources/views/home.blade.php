<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary  fixed-top">
        <div class="container " style="background-color: #e3f2fd;">
          <a class="navbar-brand" href="#">Navbar</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#kota-request">Kota</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#kategori-request">Kategori Wisata</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#kordinat-request">Coordinat</a>
              </li>
            </ul> 
          </div>
          <form action="{{ route('logout') }}" method="POST" class="d-flex" role="search">
            @csrf
            @method('DELETE')
            <button class="btn btn-danger" type="submit">Logout</button>
        </form>
        </div>
      </nav>
    
    <br>

    <div class="container mt-4"> <br>
      <h2>Dokumen API Destinasi wisata</h2>
      <p>Dokumentasi ini menjelaskan cara mengakses layanan API Destinasi Wisata. Karena menggunakan arsitektur REST dengan format balasan berupa JSON yang didukung oleh hampir semua bahasa pemrograman
        Anda dapat menggunakannya untuk aplikasi yang membutuhkan informasi dari destinasi wisata
      </p>
    </div>

    <div class="container mt-4">
      <h1>Welcome, {{ Auth::user()->name }}</h1>
      <p>Token digunakan untuk mengakses API Destinasi Wisata,
        Token berfungsi selayaknya password yang digunakan untuk mengakses data
      </p>
      <table class="table table-bordered table-success mt-4">
          <thead class="thead-light">
              <tr>
                  <th>Token Anda</th>
              </tr>
          </thead>
          <tbody>
              <tr>
                  <td>{{ Auth::user()->createToken('auth_token')->plainTextToken }}</td>
              </tr>
          </tbody>
      </table>
    </div>
<br>

<section id="kota-request" class="container mt-4">
    <h4>Request Kota</h4>
    <ul class="nav nav-tabs ro-doc-tabs">
        <li class="nav-item">
            <a class="nav-link active" data-bs-toggle="tab" href="#kota-request-url">URL</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#kota-request-parameter">Parameter</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="tab" href="#kota-request-contoh">Contoh request</a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane fade show active" id="kota-request-url">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>URL</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>GET</td>
                        <td>https://alsyahdan.cloud/api/destinasi-wisata</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="kota-request-parameter">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Key</th>
                        <th>Value</th>
                        <th>Wajib</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>GET</td>
                        <td>Bearer Token</td>
                        <td>Token</td>
                        <td>Wajib</td>
                        <td>Authorization</td>
                    </tr>
                    <tr>
                        <td>GET</td>
                        <td>id</td>
                        <td>id kota</td>
                        <td>Tidak</td>
                        <td>Identitas Kota</td>
                    </tr>
                    <tr>
                        <td>GET</td>
                        <td>lokasi</td>
                        <td>kota</td>
                        <td>Tidak</td>
                        <td>Nama kota</td>
                    </tr>
                    <tr>
                        <td>GET</td>
                        <td>nama</td>
                        <td>nama wisata</td>
                        <td>Tidak</td>
                        <td>Nama dari tempat wisata</td>
                    </tr>
                </tbody>
            </table>
            <p><strong>Catatan:</strong></p>
            <ul>
                <li>Key dan Value ditulis di bagian Params.</li>
                <li>Token dimasukkan di bagian Authorization Auth Type menggunakan Bearer Token.</li>
                <li>Jika id kosong maka akan menampilkan semua parameter.</li>
            </ul>
        </div>
        <div class="tab-pane fade" id="kota-request-contoh">
            <pre>
                <code class="language-php">
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://alsyahdan.cloud/api/destinasi-wisata",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
      "Authorization: Bearer 1234IniAdalahContohToken5678"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
                </code>
            </pre>
        </div>
    </div>
  </section>

  <section id="kategori-request" class="container mt-4">
    <h4>Request Kategori Wisata</h4>
    <ul class="nav nav-tabs ro-doc-tabs">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#kategori-request-url">URL</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#kategori-request-parameter">Parameter</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#kategori-request-contoh">Contoh request</a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane fade show active" id="kategori-request-url">
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>URL</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>GET</td>
                        <td>https://alsyahdan.cloud/api/kategori</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="tab-pane fade" id="kategori-request-parameter">
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Key</th>
                        <th>Value</th>
                        <th>Wajib</th>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>GET</td>
                        <td>Bearer Token</td>
                        <td>Token</td>
                        <td>Wajib</td>
                        <td>Authorization</td>
                    </tr>
                    <tr>
                        <td>GET</td>
                        <td>id</td>
                        <td>id kota</td>
                        <td>Tidak</td>
                        <td>Identitas Kota</td>
                    </tr>
                    <tr>
                        <td>GET</td>
                        <td>nama</td>
                        <td>Nama</td>
                        <td>Tidak</td>
                        <td>Nama dari destinasi wisata</td>
                    </tr>
                    <tr>
                        <td>GET</td>
                        <td>kategori</td>
                        <td>Kategor</td>
                        <td>Tidak</td>
                        <td>Kategori dari destinasi wisata</td>
                    </tr>
                    <tr>
                      <td>GET</td>
                      <td>rating</td>
                      <td>Rating</td>
                      <td>Tidak</td>
                      <td>Rating dari destinasi wisata</td>
                  </tr>
                </tbody>
            </table>
            <p><strong>Catatan:</strong></p>
            <ul>
                <li>Key dan Value ditulis di bagian Params.</li>
                <li>Token di masukkan di bagian Authorization Auth Type menggunakan Bearer Token.</li>
                <li>Jika id kosong maka akan menampilkan semua parameter.</li>
            </ul>
        </div>
        <div class="tab-pane fade" id="kategori-request-contoh">
            <pre>
                <code class="language-php">
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://alsyahdan.cloud/api/kategori",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
      "Authorization: Bearer 1234IniAdalahContohToken5678"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
                </code>
            </pre>
        </div>
    </div>
</section>

<section id="kordinat-request" class="container mt-4">
  <h4>Request Coordinat Lokasi Wisata</h4>
  <ul class="nav nav-tabs ro-doc-tabs">
      <li class="nav-item">
          <a class="nav-link active" data-toggle="tab" href="#kordinat-request-url">URL</a>
      </li>
      <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#kordinat-request-parameter">Parameter</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#kordinat-request-contoh">Contoh request</a>
    </li>
  </ul>
  <div class="tab-content">
      <div class="tab-pane fade show active" id="kordinat-request-url">
          <table class="table table-bordered ">
              <thead>
                  <tr>
                      <th>Method</th>
                      <th>URL</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>GET</td>
                      <td>https://alsyahdan.cloud/api/kordinat</td>
                  </tr>
              </tbody>
          </table>
      </div>
      <div class="tab-pane fade" id="kordinat-request-parameter">
          <table class="table table-bordered ">
              <thead>
                  <tr>
                      <th>Method</th>
                      <th>Key</th>
                      <th>Value</th>
                      <th>Wajib</th>
                      <th>Keterangan</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td>GET</td>
                      <td>Bearer Token</td>
                      <td>Token</td>
                      <td>Wajib</td>
                      <td>Authorization</td>
                  </tr>
                  <tr>
                      <td>GET</td>
                      <td>id</td>
                      <td>id kota</td>
                      <td>Tidak</td>
                      <td>Identitas Kota</td>
                  </tr>
                  <tr>
                      <td>GET</td>
                      <td>kordinat</td>
                      <td>Coordinat</td>
                      <td>Tidak</td>
                      <td>kordinat lokasi</td>
                  </tr>
                  <tr>
                      <td>GET</td>
                      <td>latitude</td>
                      <td>Latitude</td>
                      <td>Tidak</td>
                      <td>latitude dari lokasi tempat wisata</td>
                  </tr>
                  <tr>
                    <td>GET</td>
                    <td>longtitude</td>
                    <td>Longtitude</td>
                    <td>Tidak</td>
                    <td>Longtitude dari lokasi tempat wisata</td>
                </tr>
              </tbody>
          </table>
          <p><strong>Catatan:</strong></p>
          <ul>
              <li>Key dan Value ditulis di bagian Params.</li>
              <li>Token di masukkan di bagian Authorization Auth Type menggunakan Bearer Token.</li>
              <li>Jika id kosong maka akan menampilkan semua Coordinat dari lokasi tempat wisata.</li>
          </ul>
      </div>
      <div class="tab-pane fade" id="kordinat-request-contoh">
        <pre>
            <code class="language-php">
curl_setopt_array($curl, array(
CURLOPT_URL => "https://alsyahdan.cloud/api/kordinat",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 30,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "GET",
CURLOPT_HTTPHEADER => array(
  "Authorization: Bearer 1234IniAdalahContohToken5678"
),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
echo "cURL Error #:" . $err;
} else {
echo $response;
}
            </code>
        </pre>
    </div>
  </div>
</section>
<footer class="footer mt-auto py-3 bg-light">
    <div class="container text-center">
        <span class="text-muted">© 2024 Kelompok 4. All rights reserved.</span>
    </div>
</footer>

    
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>