<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destinasi Wisata</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #eaf2f8;
            color: #333;
        }

        header {
            background-color: #3498db;
            color: #fff;
            text-align: center;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .destination-card {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
        }

        .destination-card h2 {
            margin-bottom: 10px;
        }

        .destination-card p {
            margin-bottom: 5px;
        }

        .destination-card .deskripsi {
            margin-top: 10px;
        }

        #search-form {
            margin: 20px auto;
            width: 50%;
            text-align: center;
        }

        #search-form input[type="text"] {
            padding: 10px;
            width: 70%;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        #search-form button {
            padding: 10px 20px;
            border: none;
            background-color: #3498db;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }

        #category-form,
        #coordinate-form {
            margin-top: 20px;
        }

        #category-form input[type="text"],
        #coordinate-form input[type="text"] {
            padding: 10px;
            width: 60%;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        #category-form button,
        #coordinate-form button {
            padding: 10px 20px;
            border: none;
            background-color: #3498db;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <header>
        <h1>Destinasi Wisata</h1>
    </header>
    <div id="search-form">
        <form action="search_kategori.php" method="GET">
            <button type="submit">Kategori</button>
        </form>
    </div>

    <div id="search-form">
        <form action="search_coordinate.php" method="GET">
            <button type="submit">Koordinat</button>
        </form>



    <?php
    // Ambil data destinasi wisata
    $curl_destinasi = curl_init();
    curl_setopt_array($curl_destinasi, array(
        CURLOPT_URL => "https://alsyahdan.cloud/api/destinasi-wisata",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer wB8RfKWclmXXBlqVer4fjfP0JA7qNOQMz2pHaDcl"
        ),
    ));
    $response_destinasi = curl_exec($curl_destinasi);
    $err_destinasi = curl_error($curl_destinasi);
    curl_close($curl_destinasi);

    // Cek kesalahan saat mengambil data destinasi
    if ($err_destinasi) {
        echo "Error fetching data from API";
    } else {
        // Decode respons JSON destinasi
        $destinasi_data = json_decode($response_destinasi, true);

        // Periksa apakah data ada dan memiliki kunci 'data'
        if (isset($destinasi_data['data']) && is_array($destinasi_data['data'])) {
            // Loop melalui setiap destinasi
            foreach ($destinasi_data['data'] as $destinasi) {
                // Pastikan destinasi memiliki kunci 'nama' dan 'lokasi'
                if (isset($destinasi['nama']) && isset($destinasi['lokasi'])) {
                    echo "<div class='destination-card'>";
                    echo "<h2>" . $destinasi['nama'] . "</h2>";
                    echo "<p>Lokasi: " . $destinasi['lokasi'] . "</p>";
                    echo "</div>";
                } else {
                    echo "<div class='destination-card'>";
                    echo "<h2>Error: Invalid Data</h2>";
                    echo "<p>Destinasi tidak memiliki informasi yang cukup.</p>";
                    echo "</div>";
                }
            }
        } else {
            echo "<div class='destination-card'>";
            echo "<h2>Error: Invalid Data</h2>";
            echo "<p>Data destinasi tidak valid.</p>";
            echo "</div>";
        }
    }
    ?>



</body>

</html>